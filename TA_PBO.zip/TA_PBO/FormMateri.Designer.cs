﻿namespace TA_PBO
{
    partial class FormMateri
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormMateri));
            this.splitter1 = new System.Windows.Forms.Splitter();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnBack = new System.Windows.Forms.Button();
            this.pnlPenanda = new System.Windows.Forms.Panel();
            this.btnPrisma = new System.Windows.Forms.Button();
            this.btnBola = new System.Windows.Forms.Button();
            this.btnBalok = new System.Windows.Forms.Button();
            this.lblKet = new System.Windows.Forms.Label();
            this.lblTitle = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // splitter1
            // 
            this.splitter1.BackColor = System.Drawing.Color.Blue;
            this.splitter1.Location = new System.Drawing.Point(0, 0);
            this.splitter1.Name = "splitter1";
            this.splitter1.Size = new System.Drawing.Size(147, 375);
            this.splitter1.TabIndex = 0;
            this.splitter1.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Blue;
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(24, 25);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(100, 100);
            this.pictureBox1.TabIndex = 12;
            this.pictureBox1.TabStop = false;
            // 
            // btnBack
            // 
            this.btnBack.BackColor = System.Drawing.Color.Blue;
            this.btnBack.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnBack.BackgroundImage")));
            this.btnBack.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnBack.FlatAppearance.BorderSize = 0;
            this.btnBack.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBack.Location = new System.Drawing.Point(12, 323);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(40, 40);
            this.btnBack.TabIndex = 13;
            this.btnBack.UseVisualStyleBackColor = false;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // pnlPenanda
            // 
            this.pnlPenanda.BackColor = System.Drawing.Color.Red;
            this.pnlPenanda.Location = new System.Drawing.Point(-1, 131);
            this.pnlPenanda.Name = "pnlPenanda";
            this.pnlPenanda.Size = new System.Drawing.Size(11, 40);
            this.pnlPenanda.TabIndex = 18;
            // 
            // btnPrisma
            // 
            this.btnPrisma.BackColor = System.Drawing.Color.Blue;
            this.btnPrisma.FlatAppearance.BorderSize = 0;
            this.btnPrisma.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPrisma.Font = new System.Drawing.Font("Signika", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPrisma.ForeColor = System.Drawing.Color.White;
            this.btnPrisma.Location = new System.Drawing.Point(12, 223);
            this.btnPrisma.Name = "btnPrisma";
            this.btnPrisma.Size = new System.Drawing.Size(135, 40);
            this.btnPrisma.TabIndex = 17;
            this.btnPrisma.Text = "Prism";
            this.btnPrisma.UseVisualStyleBackColor = false;
            this.btnPrisma.Click += new System.EventHandler(this.btnPrisma_Click);
            // 
            // btnBola
            // 
            this.btnBola.BackColor = System.Drawing.Color.Blue;
            this.btnBola.FlatAppearance.BorderSize = 0;
            this.btnBola.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBola.Font = new System.Drawing.Font("Signika", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBola.ForeColor = System.Drawing.Color.White;
            this.btnBola.Location = new System.Drawing.Point(12, 131);
            this.btnBola.Name = "btnBola";
            this.btnBola.Size = new System.Drawing.Size(135, 40);
            this.btnBola.TabIndex = 16;
            this.btnBola.Text = "Sphere";
            this.btnBola.UseVisualStyleBackColor = false;
            this.btnBola.Click += new System.EventHandler(this.btnBola_Click);
            // 
            // btnBalok
            // 
            this.btnBalok.BackColor = System.Drawing.Color.Blue;
            this.btnBalok.FlatAppearance.BorderSize = 0;
            this.btnBalok.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBalok.Font = new System.Drawing.Font("Signika", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBalok.ForeColor = System.Drawing.Color.White;
            this.btnBalok.Location = new System.Drawing.Point(12, 177);
            this.btnBalok.Name = "btnBalok";
            this.btnBalok.Size = new System.Drawing.Size(135, 40);
            this.btnBalok.TabIndex = 15;
            this.btnBalok.Text = "Cube";
            this.btnBalok.UseVisualStyleBackColor = false;
            this.btnBalok.Click += new System.EventHandler(this.btnBalok_Click);
            // 
            // lblKet
            // 
            this.lblKet.AutoSize = true;
            this.lblKet.BackColor = System.Drawing.Color.Transparent;
            this.lblKet.Font = new System.Drawing.Font("Signika", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblKet.Location = new System.Drawing.Point(153, 72);
            this.lblKet.Name = "lblKet";
            this.lblKet.Size = new System.Drawing.Size(51, 19);
            this.lblKet.TabIndex = 19;
            this.lblKet.Text = "label1";
            // 
            // lblTitle
            // 
            this.lblTitle.BackColor = System.Drawing.Color.Transparent;
            this.lblTitle.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblTitle.Font = new System.Drawing.Font("Signika", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.Location = new System.Drawing.Point(147, 0);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(357, 56);
            this.lblTitle.TabIndex = 20;
            this.lblTitle.Text = "Sphere";
            this.lblTitle.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(161, 25);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(335, 350);
            this.pictureBox2.TabIndex = 21;
            this.pictureBox2.TabStop = false;
            // 
            // FormMateri
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(504, 375);
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.lblKet);
            this.Controls.Add(this.pnlPenanda);
            this.Controls.Add(this.btnPrisma);
            this.Controls.Add(this.btnBola);
            this.Controls.Add(this.btnBalok);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.splitter1);
            this.Controls.Add(this.pictureBox2);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FormMateri";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FormMateri";
            this.Load += new System.EventHandler(this.FormMateri_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Splitter splitter1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.Panel pnlPenanda;
        private System.Windows.Forms.Button btnPrisma;
        private System.Windows.Forms.Button btnBola;
        private System.Windows.Forms.Button btnBalok;
        private System.Windows.Forms.Label lblKet;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}