﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TA_PBO
{
    interface IAkun
    {
        string Username { get; }
        string Password { get; }
    }
}
